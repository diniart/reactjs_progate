import React from 'react';
import ReactDOM from 'react-dom';
import App from './components/App';
// Tempelkan code yang disiapkan di kolom instruksi di bawah
ReactDOM.render(<App />, document.getElementById('root'));